package com.example.demo.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table (name="Hotel")
public class Hotels {
	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="hotelId")
	private int hotelId;
	
	@NotNull(message = "Hotel name can not be empty")
    @Size(max = 20,message = "Hptel name can't be more than 20 characters")@Size(min=1, message="Hotel name must be more than 1 characters")
	@Column(name="hotelName")
	private String hotelName;
	
	@NotBlank(message = "location can not be empty")
    @Size(max = 50,message = " location can't be more than 50 characters")
    @Size(min=0, message="location must be more than 2 characters")
    @Column(name="location")
	private String location;
	
	
    @Max(value=100000, message ="hotelPrice should not be greater than 10000" )
    @Min(value=0, message="hotelPrice must be greater than 1000")
	@Column(name="hotelPrice")
    private int hotelPrice;
	
	@NotNull(message = "number of rooms can not be null")@Min(value=0, message="number of rooms must be greater than 0")
	@Column(name="noofrooms")
	private int noOfRooms;
	
	//@Max(value=100000, message =" Price should not be greater than 10000" )@Min(value=0, message="  Price must be greater than 1000")
	@Column(name="about")
	private String about;

	
	@NotBlank(message = " rating  can not be empty")
	@Max(value=5, message ="rating should not be greater than 5" )@Min(value=0, message="rating  must be greater than 0")
	@Column(name="rating")
	private String rating;
	
	
	//@Max(value=4, message ="rating should not be greater than 5" )@Min(value=0, message="rating  must be greater than 0")
	//@Column(name="personsPerRoom")private int personsPerRoom;
	
	
	@Column(name="images")
	private String images;
	
	@Column(name="facilities")
	private String facilities;
	
	
public Hotels() {
		
	}

	public Hotels(int hotelId, String hotelName, String hotelAddress , int hotelPrice,String about, int noOfRooms,
			 String facilities , String rating,String images)
			 {
		
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		//this.hotelAddress = hotelAddress;
		this.facilities = facilities;
		this.hotelPrice = hotelPrice ;
		this.about = about  ;
		this.noOfRooms = noOfRooms;
		this.rating = rating;
		this.images=images;
		
}

	public String getImages() {
		return images;
	}

	public void setImages(String images) {
		this.images = images;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}


	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public int getHotelPrice() {
		return hotelPrice;
	}

	public void setHotelPrice(int hotelPrice) {
		this.hotelPrice = hotelPrice;
	}

	public int getNoOfRooms() {
		return noOfRooms;
	}

	public void setNoOfRooms(int noOfRooms) {
		this.noOfRooms = noOfRooms;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String getFacilities() {
		return facilities;
	}

	public void setFacilities(String facilities) {
		this.facilities = facilities;
	}

	

	
}