package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.UserDao;
import com.example.demo.entity.User;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.service.UserService;
//import com.example.demo.service.EmailService;

@CrossOrigin(origins = "http://localhost:4200/")
@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserService service;
    @Autowired
    UserDao dao;
   // @Autowired
   // EmailService emailservice;

    @PostMapping("/signup")
    public ResponseEntity<Map<String, String>> singup(@RequestBody User user) {
        System.out.println("Received a signup request for user: " + user.getUsername());

        this.service.addUser(user);

        System.out.println("User registered: " + user);
        
        //emailservice.sendEmail(customer.getEmail(), "SignUp Email", "SignUP is Successful in Restaurant Management System as a Customer.\nYour username is: " + customer.getUsername());

        Map<String, String> response = new HashMap<String, String>();
        response.put("status", "success");
        response.put("message", "User registered!!");
        return new ResponseEntity<Map<String, String>>(response, HttpStatus.CREATED);
    }

    @GetMapping("/viewuser")
    public ResponseEntity<List<User>> findAll() {
        System.out.println("Received a request to get all user data.");

        List<User> users = this.service.findALL();

        System.out.println("Returning all user data:");
        for (User user : users) {
            System.out.println(user); 
        }

        return new ResponseEntity<List<User>>(users, HttpStatus.OK);
    }


    @GetMapping("/id/{id}")
    public ResponseEntity<User> getUserById(@PathVariable long id) {
        System.out.println("Received a request to get user by ID: " + id);

        Optional<User> userOptional = dao.findById(id);

        if (userOptional.isPresent()) {
            System.out.println("Returning user for ID: " + id);
            return ResponseEntity.ok(userOptional.get());
        } else {
            System.out.println("user not found for ID: " + id);
            throw new UserNotFoundException("user with Id " + id + " not found.");
        }
    }

    @GetMapping("/username/{username}")
    public ResponseEntity<User> getUserByUsername(@PathVariable String username) {
        System.out.println("Received a request to get user by username: " + username);

        User user = service.getUserByUsername(username);
        if (user == null) {
            System.out.println("User not found for username: " + username);
            throw new UserNotFoundException("User with username " + username + " not found.");
        }

        System.out.println("Returning user for username: " + user);
        return new ResponseEntity<>(user, HttpStatus.OK);
    }

    @PutMapping("/update")
    public ResponseEntity<Map<String, String>> updateUser(@RequestBody User e) {
        System.out.println("Received a request to update user data: " + e);

        try {
            if (this.dao.findById(e.getUserId()).isPresent()) {
                User existingUser = this.dao.findById(e.getUserId()).get();
                existingUser.setUsersName(e.getUsersName());
                existingUser.setUserPhone(e.getUserPhone());
                existingUser.setUsername(e.getUsername());
                existingUser.setUserpassword(e.getUserpassword());
                existingUser.setEmail(e.getEmail());
                this.dao.save(existingUser);

                Map<String, String> response = new HashMap<String, String>();
                response.put("status", "success");
                response.put("message", "User data updated!!");
                System.out.println("User data updated successfully: " + existingUser);
                return new ResponseEntity<Map<String, String>>(response, HttpStatus.CREATED);
            } else {
                Map<String, String> response = new HashMap<String, String>();
                response.put("status", "failed");
                response.put("message", "User data not found!!");
                System.out.println("User data not found for updating: " + e.getUserId());
                return new ResponseEntity<Map<String, String>>(response, HttpStatus.NOT_FOUND);
            }
        } catch (Exception e1) {
            Map<String, String> response = new HashMap<String, String>();
            response.put("status", "failed");
            response.put("message", "User data not updated!!");
            System.out.println("Failed to update user data: " + e1.getMessage());
            return new ResponseEntity<Map<String, String>>(response, HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Map<String, String>> deleteUser(@PathVariable(name = "id") int id) {
        System.out.println("Received a request to delete customer data by ID: " + id);

        try {
            this.service.deleteById(id);
            System.out.println("User data deleted successfully for ID: " + id);
            Map<String, String> response = new HashMap<String, String>();
            response.put("status", "success");
            response.put("message", "User data deleted!!");
            return new ResponseEntity<Map<String, String>>(response, HttpStatus.OK);
        } catch (Exception e) {
            System.out.println("Failed to delete user data for ID: " + id);
            Map<String, String> response = new HashMap<String, String>();
            response.put("status", "failed");
            response.put("message", "user data not deleted!!");
            return new ResponseEntity<Map<String, String>>(response, HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/loginn")
    public ResponseEntity<Map<String, String>> login(@RequestParam("username") String username,
            @RequestParam("userpassword") String password) {
        System.out.println("Received a login request for customer: " + username);

        Optional<User> existingUsers = this.service.getUserByName(username);
        Map<String, String> response = new HashMap<String, String>();
        if (existingUsers.isPresent()) {
            if (existingUsers.get().getUserpassword().equals(password)) {
                System.out.println("User login successful for: " + username);

                response.put("status", "success");
                response.put("message", "User authenticated");
                response.put("UserId", String.valueOf(existingUsers.get().getUserId()));
                response.put("UsersName", existingUsers.get().getUsersName());
                return new ResponseEntity<Map<String, String>>(response, HttpStatus.OK);
            } else {
                System.out.println("User login failed due to incorrect password for: " + username);

                response.put("status", "Failed");
                response.put("message", "User password incorrect");
                return new ResponseEntity<Map<String, String>>(response, HttpStatus.NOT_FOUND);
            }
        } else {
            System.out.println("User login failed because user does not exist for: " + username);

            response.put("status", "Failed");
            response.put("message", "User does not exist");
            return new ResponseEntity<Map<String, String>>(response, HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody User userData) {
        System.out.println("Received a login request for user: " + userData.getUsername());

        User user = service.findByUsername(userData.getUsername());

        if (user.getUserpassword().equals(userData.getUserpassword())) {
            System.out.println("User login successful: " + user);

            User senduser = new User();
            senduser.setUserId(user.getUserId());
            senduser.setUsername(user.getUsername());
            senduser.setUserPhone(user.getUserPhone());
            senduser.setUsername(user.getUsername());
            senduser.setEmail(user.getEmail());

            return ResponseEntity.ok(senduser);
        } else {
            System.out.println("user login failed for: " + userData.getUsername());
            return (ResponseEntity<?>) ResponseEntity.internalServerError();
        }
    }
}
