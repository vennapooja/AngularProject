package com.example.demo.service;

import com.example.demo.entity.ShoppingMalls;

import java.util.List;
import java.util.Optional;
public interface ShoppingMallsService 
	{
	public List<ShoppingMalls>findAll();
	public Optional<ShoppingMalls>findById(int ShopId);
	public void saveorUpdate(ShoppingMalls s);
	public void deleteById(int ShopId);
	public void saveShoppingMalls(ShoppingMalls s);

	
	
    }