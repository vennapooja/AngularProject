package com.example.demo.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Booking;
import com.example.demo.exception.BookingNotFoundException;
import com.example.demo.service.BookingService;

import java.util.List;
@CrossOrigin(origins = "http://localhost:4200/")
@RestController
@RequestMapping("Booking")
public class BookingController {

    private final BookingService bookingService;

    @Autowired
    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @GetMapping
    public ResponseEntity<List<Booking>> getAllBookings() {
        System.out.println("Received a request to fetch all bookings.");
        
        List<Booking> bookings = bookingService.getAllBookings();
        System.out.println("Returning all bookings: " + bookings);

        return new ResponseEntity<>(bookings, HttpStatus.OK);
    }

    @GetMapping("/{bookingId}")
    public ResponseEntity<Booking> getBookingById(@PathVariable Long bookingId) {
        System.out.println("Received a request to fetch Booking by ID: " + bookingId);

        Booking booking = bookingService.getBookingById(bookingId);
        if (booking == null) {
            System.out.println("Booking not found for ID: " + bookingId);
            throw new BookingNotFoundException("Booking with ID " + bookingId + " not found.");
        }

        System.out.println("Returning booking for ID " + bookingId + ": " + booking);
        return new ResponseEntity<>(booking, HttpStatus.OK);
    }

    @PostMapping("/create/{hotelId}/{userId}")
    public ResponseEntity<Booking> createbooking(@RequestBody Booking booking, @PathVariable long userId,
                                             @PathVariable int hotelId) {
       
		System.out.println("Received a request to create booking for user ID: " + userId + " and hotel ID: " + hotelId);

        Booking savedBooking = bookingService.saveBooking(booking, userId, hotelId);
        System.out.println("Hotel Booked successfully: " + savedBooking);

        return ResponseEntity.ok(savedBooking);
    }

    @DeleteMapping("/delete/{bookingId}")
    public ResponseEntity<Void> deleteBooking(@PathVariable Long bookingId) {
        System.out.println("Received a request to delete booking by ID: " + bookingId);

        bookingService.deleteBooking(bookingId);
        System.out.println("Booking deleted successfully for ID: " + bookingId);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getBookingsByUserId(@PathVariable long userId) {
        System.out.println("Received a request to fetch bookings by user ID: " + userId);

        try {
            List<Booking> bookings = bookingService.findBookingsByUserId(userId);
            if (bookings.isEmpty()) {
                System.out.println("No bookings found for user ID: " + userId);
                return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
            }

            System.out.println("Returning bookings for user ID " + userId + ": " + bookings);
            return ResponseEntity.ok(bookings);
        } catch (Exception e) {
            System.out.println("An error occurred while fetching bookings for user ID " + userId + ": " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An error occurred: " + e.getMessage());
        }
    }
}
