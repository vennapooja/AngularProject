package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.TouristDao;
import com.example.demo.entity.Hotels;
import com.example.demo.entity.TouristPlace;
import com.example.demo.service.TouristService;
@CrossOrigin(origins = "http://localhost:4200/")
@RestController
@RequestMapping("Tourist")
public class TouristController {

    @Autowired
    TouristService service;

    @Autowired
    TouristDao dao;

    @GetMapping("/list")
    public ResponseEntity<List<TouristPlace>> findAll() {
        return new ResponseEntity<List<TouristPlace>>(this.service.findAll(), HttpStatus.OK);
    }

    @GetMapping("/find/{placeId}")
    public ResponseEntity<?> getTouristPlaceById(@PathVariable int placeId) {
        if (this.service.findByPlaceId(placeId).isPresent()) {
            return new ResponseEntity<TouristPlace>(this.service.findByPlaceId(placeId).get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<String>("TouristPlace Id not found!", HttpStatus.NOT_FOUND);
        }
    }
    
    @PostMapping("/add")
    public ResponseEntity<Map<String,String>> saveProduct(@RequestBody TouristPlace T)
    {
        try
        {
            Optional<TouristPlace> existingplace=this.dao.findById(T.getPlaceId());
            if(existingplace.isEmpty())
            {
                
        
            this.service.saveTouristPlace(T);
            Map<String,String> response=new HashMap<String,String>();
            response.put("status", "success");
            response.put("message", "Tourist Place added!!");
            return new ResponseEntity<Map<String,String>>(response, HttpStatus.CREATED);
            }
            else
            {
                Map<String,String> response=new HashMap<String,String>();
                response.put("status", "failed");
                response.put("message", "Tourist Place already  found!!");
                return new ResponseEntity<Map<String,String>>(response, HttpStatus.NOT_FOUND);
            }
        }
        catch(Exception e1)
        {
            Map<String,String> response=new HashMap<String,String>();
            response.put("status", "failed");
            response.put("message", "Tourist Place not added!!");
            return new ResponseEntity<Map<String,String>>(response, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/update")
    public ResponseEntity<Map<String, String>> updateTouristPlace(@RequestBody TouristPlace t) {
        try {
            if (this.dao.findByPlaceId(t.getPlaceId()).isPresent()) {
                TouristPlace existingPlace = this.dao.findByPlaceId(t.getPlaceId()).get();
                existingPlace.setPlaceName(t.getPlaceName());
                existingPlace.setLocation(t.getLocation());
                existingPlace.setTimings(t.getTimings());
                existingPlace.setTicketPriceChildren(t.getTicketPriceChildren());
                existingPlace.setTicketPriceAdults(t.getTicketPriceAdults());
                existingPlace.setDescription(t.getDescription());
                existingPlace.setContact(t.getContact());
                existingPlace.setEmailid(t.getEmailid());
                existingPlace.setRating(t.getRating());
                existingPlace.setImg(t.getImg());
                
                this.service.saveorUpdate(existingPlace);
                Map<String, String> response = new HashMap<String, String>();
                response.put("status", "success");
                response.put("message", "TouristPlace data updated!!");
                return new ResponseEntity<Map<String, String>>(response, HttpStatus.CREATED);
            } else {
                Map<String, String> response = new HashMap<String, String>();
                response.put("status", "failed");
                response.put("message", "TouristPlace data not found!!");
                return new ResponseEntity<Map<String, String>>(response, HttpStatus.NOT_FOUND);
            }
        } catch (Exception e1) {
            Map<String, String> response = new HashMap<String, String>();
            response.put("status", "failed");
            response.put("message", "TouristPlace not updated!!");
            return new ResponseEntity<Map<String, String>>(response, HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/delete/{placeId}")
    public ResponseEntity<Map<String, String>> deleteTouristPlaceById(@PathVariable int placeId) {
        try {
            this.service.deleteByPlaceId(placeId);
            Map<String, String> response = new HashMap<String, String>();
            response.put("status", "success");
            response.put("message", "TouristPlace data deleted!!");
            return new ResponseEntity<Map<String, String>>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, String> response = new HashMap<String, String>();
            response.put("status", "failed");
            response.put("message", "TouristPlace data not deleted!!");
            return new ResponseEntity<Map<String, String>>(response, HttpStatus.NOT_FOUND);
        }
    }
   /* @GetMapping("/search")
	public ResponseEntity<?> getTouristPlaceByPlaceName(@RequestParam("placeName") String placeName)
	{
		//postTitle=postTitle.toLowerCase();
		if(this.service.getTouristPlaceByPlaceName(placeName).isPresent())
		{
			return new ResponseEntity<TouristPlace>(this.service.getTouristPlaceByPlaceName(placeName).get(),HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<String>("No Tourist Place found!",HttpStatus.NOT_FOUND);
		}
	}*/
    @GetMapping("/search")
	public ResponseEntity<?> getTouristPlaceByplaceName(@RequestParam("placeName") String placeName)
	{
		
		if(this.service.getTouristPlaceByPlaceName(placeName).isPresent())
		{
			return new ResponseEntity<TouristPlace>(HttpStatus.OK);
			//return new ResponseEntity<TouristPlace>(this.service.getTouristPlaceByPlaceName(placeName),HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<String>("No Place found!",HttpStatus.NOT_FOUND);
		}
	}
	
}