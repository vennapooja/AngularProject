package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.ShoppingMallsDao;
import com.example.demo.entity.ShoppingMalls;
import com.example.demo.service.ShoppingMallsService;

import net.bytebuddy.dynamic.DynamicType.Builder.FieldDefinition.Optional;

@RestController
@RequestMapping("ShoppingMalls")
public class ShoppingMallsController
{
	
	@Autowired
	ShoppingMallsService service;
	@Autowired
	ShoppingMallsDao dao;
	@GetMapping("/list")
	public ResponseEntity<List<ShoppingMalls>>findAll()
	{
		return new ResponseEntity<List<ShoppingMalls>>(this.service.findAll(), HttpStatus.OK);
	}
	@GetMapping("/find/{Shop_Id}")
	public ResponseEntity<?> getShoppingMallsById(@PathVariable int Shop_Id)
	{
		if(this.service.findById(Shop_Id).isPresent())
		{
			return new ResponseEntity<ShoppingMalls>(this.service.findById(Shop_Id).get(),HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<String>("ShoppingMalls Id  not found!",HttpStatus.NOT_FOUND);
		}
		
	}
	 @PostMapping("/list/add")
	    public ResponseEntity<Map<String,String>> saveShoppingMalls(@RequestBody ShoppingMalls s)
	    {
	        try
	        {
	            java.util.Optional<ShoppingMalls> existingMalls=this.dao.findById(s.getShop_Id());
	            if(existingMalls.isEmpty())
	            {
	                
	        
	            this.service.saveShoppingMalls(s);
	            Map<String,String> response=new HashMap<String,String>();
	            response.put("status", "success");
	            response.put("message", "ShoppingMalls added!!");
	            return new ResponseEntity<Map<String,String>>(response, HttpStatus.CREATED);
	            }
	            else
	            {
	                Map<String,String> response=new HashMap<String,String>();
	                response.put("status", "failed");
	                response.put("message", "ShoppingMalls already  found!!");
	                return new ResponseEntity<Map<String,String>>(response, HttpStatus.NOT_FOUND);
	            }
	        }
	        catch(Exception e1)
	        {
	            Map<String,String> response=new HashMap<String,String>();
	            response.put("status", "failed");
	            response.put("message", "ShoppingMalls not added!!");
	            return new ResponseEntity<Map<String,String>>(response, HttpStatus.BAD_REQUEST);
	        }
	    }

	    @PutMapping("/update")
	    public ResponseEntity<Map<String, String>> updateShoppingMalls(@RequestBody ShoppingMalls s) {
	        try {
	            if (this.dao.findById(s.getShop_Id()).isPresent()) {
	            	ShoppingMalls existingMalls = this.dao.findById(s.getShop_Id()).get();
	                existingMalls.setShop_Name(s.getShop_Name());
	                existingMalls.setShop_Address(s.getShop_Address ());
	                existingMalls.setCategory(s.getCategory());
	                existingMalls.setShop_Timings(s.getShop_Timings());
	                existingMalls.setRating(s.getRating());
	          	  

	                this.service.saveorUpdate(s);
	                Map<String, String> response = new HashMap<String, String>();
	                response.put("status", "success");
	                response.put("message", "ShoppingMalls data updated!!");
	                return new ResponseEntity<Map<String, String>>(response, HttpStatus.CREATED);
	            } else {
	                Map<String, String> response = new HashMap<String, String>();
	                response.put("status", "failed");
	                response.put("message", "ShoppingMalls data not found!!");
	                return new ResponseEntity<Map<String, String>>(response, HttpStatus.NOT_FOUND);
	            }
	        } catch (Exception e1) {
	            Map<String, String> response = new HashMap<String, String>();
	            response.put("status", "failed");
	            response.put("message", "ShoppingMalls not updated!!");
	            return new ResponseEntity<Map<String, String>>(response, HttpStatus.BAD_REQUEST);
	        }
	    }

	@DeleteMapping("/delete/{Shop_Id}")
	public ResponseEntity<Map<String,String>> deleteById(@PathVariable int Shop_Id)
	{
		try
		{
			this.service.deleteById(Shop_Id);
			Map<String,String> response=new HashMap<String,String>();
			response.put("status", "success");
			response.put("message", "Shopping Malls data deleted!!");
			return new ResponseEntity<Map<String,String>>(response, HttpStatus.OK);
		}
		catch(Exception e)
		{
			Map<String,String> response=new HashMap<String,String>();
			response.put("status", "failed");
			response.put("message", "Shopping Malls data not deleted!!");
			return new ResponseEntity<Map<String,String>>(response, HttpStatus.NOT_FOUND);
		}

}
}