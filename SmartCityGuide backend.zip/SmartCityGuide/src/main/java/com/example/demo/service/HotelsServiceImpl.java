package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.HotelsDao;
import com.example.demo.entity.Hotels;


	@Service
	public class HotelsServiceImpl implements HotelsService
	{
		@Autowired
	   HotelsDao dao;
		@Override
		public List<Hotels> findAll() {
			return dao.findAll();
		}
		@Override
		public Optional<Hotels> findByhotelId(int hotelId) {
			return dao.findByhotelId(hotelId);
		}
		@Override
	    public void savedata(Hotels H) {
	        dao.save(H);
		}   
		 @Override
			public void saveorUpdate(Hotels H) {
				dao.save(H);
			}
		 @Override
			public void deleteByhotelId(int hotelId) {
				dao.deleteById(hotelId);
				
			}
		@Override
		public Optional<Hotels> getHotelsByhotelName(String hotelName) {
			return this.dao.findByhotelNameIgnoreCase(hotelName);
			//return Optional.empty();
		}
	
				
}