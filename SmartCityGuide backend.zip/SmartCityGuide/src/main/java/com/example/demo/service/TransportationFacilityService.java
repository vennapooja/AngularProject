package com.example.demo.service;


import com.example.demo.entity.TransportationFacility;


import java.util.List;
import java.util.Optional;

public interface TransportationFacilityService 
	{
	public List<TransportationFacility>findAll();
	public Optional<TransportationFacility>findById(int id);
	public void saveTransportation(TransportationFacility T);
	public void saveorUpdate(TransportationFacility T);
	public void deleteById(int id);	
   // public List<TransportationFacility> findByTransportationType(String transportationType);
	
   public Optional<TransportationFacility> getTransportationFacilityBytransportationType(String transportationType);
   

}
	
		
		
		
