package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.TouristDao;
import com.example.demo.entity.TouristPlace;

@Service
public class TouristServiceImpl implements TouristService {

    @Autowired
    private TouristDao dao;

    @Override
	public List<TouristPlace> findAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}
	@Override
	public Optional<TouristPlace> findByPlaceId(int placeId) {
		// TODO Auto-generated method stub
		return dao.findByPlaceId(placeId);
	}
	 @Override
	    public void saveTouristPlace(TouristPlace T) {
	        dao.save(T);
	        
	    }
	 @Override
		public void saveorUpdate(TouristPlace T) {
			dao.save(T);
			
		}
	 @Override
		public void deleteByPlaceId(int placeId) {
			dao.deleteById(placeId);
			
		}
	@Override
	public Optional<TouristPlace>getTouristPlaceByPlaceName(String placeName) {
		// TODO Auto-generated method stub
		return Optional.empty();

	}
	
	
	//@Override
	//public List<TouristPlace> findByPname(String placeName) {
		// TODO Auto-generated method stub
		//return TouristDao.findByPnameIgnoreCase(placeName);

	//}
	//@Override
	//public TouristPlace findTouristPlaceByplaceName(String placeName) {
		// TODO Auto-generated method stub
	//	return TouristDao .findTouristPlaceByPlaceName(placeName);

	//}
	
	
}