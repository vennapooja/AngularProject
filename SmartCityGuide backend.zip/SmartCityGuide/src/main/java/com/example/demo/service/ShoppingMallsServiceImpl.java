package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.ShoppingMallsDao;
import com.example.demo.entity.ShoppingMalls;
@Service
public class ShoppingMallsServiceImpl implements ShoppingMallsService
{
	 @Autowired
	    private ShoppingMallsDao dao;

	    @Override
		public List<ShoppingMalls> findAll() {
			// TODO Auto-generated method stub
			return dao.findAll();
		}
		@Override
		public Optional<ShoppingMalls> findById(int ShopId) {
			// TODO Auto-generated method stub
			return dao.findById(ShopId);
		}
		 @Override
		    public void saveShoppingMalls(ShoppingMalls s) {
		        dao.save(s);
		        
		    }
		 @Override
			public void saveorUpdate(ShoppingMalls s) {
				dao.save(s);
				
			}
		 @Override
			public void deleteById(int ShopId) {
				dao.deleteById(ShopId);
				
			
		
		}
}
