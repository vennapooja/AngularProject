package com.example.demo.entity;
import javax.persistence.*;
import javax.validation.constraints.*	;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

@Entity
@Table(name = "HotelBookings")
public class Booking {

	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "bookingId", unique = true)
	    private Long bookingId;

	    @ManyToOne(targetEntity = User.class, cascade = { CascadeType.MERGE}, fetch = FetchType.EAGER)
	    @JoinColumn(name = "user_id", referencedColumnName = "user_id")
	    private User user;

	    @Column(name = "booking_date")
	    @Temporal(TemporalType.DATE)
	    private Date bookingDate;

	    @Column(name = "booking_time")
	    @Temporal(TemporalType.TIME)
	    @JsonFormat(pattern = "HH:mm:ss", timezone = "UTC")
	    private Date bookingTime;

	    @ManyToOne(targetEntity = Hotels.class, cascade = { CascadeType.MERGE }, fetch = FetchType.EAGER)
	    @JoinColumn(name = "hotelId", referencedColumnName = "hotelId")
	    private Hotels hotel;

	    @Column(name = "noOfRooms")
	    private int noOfRooms;

	    @Column(name = "totalprice")
	    private double totalPrice;

	    @NotBlank(message = "Booking status cannot be blank")
	    @Column(name = "status")
	    private String status;



	public Booking() {
	}

	
	


	public Booking(Long bookingId, User user, Date bookingDate, Date bookingTime, Hotels hotel, int noOfRooms,
			double totalPrice, @NotBlank(message = "Booking status cannot be blank") String status) {
		super();
		this.bookingId = bookingId;
		this.user = user;
		this.bookingDate = bookingDate;
		this.bookingTime = bookingTime;
		this.hotel = hotel;
		this.noOfRooms = noOfRooms;
		this.totalPrice = totalPrice;
		this.status = status;
	}
	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Date getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	public Date getBookingTime() {
		return bookingTime;
	}

	public void setBookingTime(Date bookingTime) {
		this.bookingTime = bookingTime;
	}

	public Hotels getHotel() {
		return hotel;
	}

	public void setHotel(Hotels hotel) {
		this.hotel = hotel;
		calculateTotalPrice();
	}
	public int getNoOfRooms() {
		return noOfRooms;
	}

	public void setNoOfRooms(int noOfRooms) {
		this.noOfRooms = noOfRooms;
		calculateTotalPrice();
	}

	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	public void calculateTotalPrice() {
		if (hotel != null) {
			
			totalPrice = hotel.getHotelPrice() * noOfRooms;
		}
		else
		{
			totalPrice = 0.0; 
		}
		
	
	}





	public double getTotalPrice() {
		return totalPrice;
	}

	

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}





	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", user=" + user + ", bookingDate=" + bookingDate + ", bookingTime="
				+ bookingTime + ", hotel=" + hotel + ", noOfRooms=" + noOfRooms + ", totalPrice=" + totalPrice
				+ ", status=" + status + "]";
	}
	
	
	
	
}
