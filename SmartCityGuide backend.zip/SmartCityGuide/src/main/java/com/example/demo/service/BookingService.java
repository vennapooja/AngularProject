package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Booking;

public interface BookingService {
	public List<Booking> getAllBookings();

	public Booking getBookingById(Long bookingId);

	public Booking saveBooking(Booking booking,long userId,int hotelId);

	public void deleteBooking(Long bookingId);
	
	public List<Booking> findBookingsByUserId(long userId);

	Booking getBookingById(int bookingId);

}