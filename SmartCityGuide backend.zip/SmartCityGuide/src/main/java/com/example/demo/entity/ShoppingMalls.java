package com.example.demo.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.CreationTimestamp;
@Entity
@Table(name="Shopping_Malls")
public class ShoppingMalls
{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="Shop_Id")
    private int Shop_Id;
    @NotNull(message = "Shop Id can not be empty")
    @Size(max =100,message = "Shop Id can't be more than 100 characters")
    @Size(min=5, message="Shop Id must be more than 5 characters")
    
    @Column(name="Shop_Name")
    private String Shop_Name;
    @NotBlank(message = "Shop_Name  can not be empty")
    @Size(max =100,message = "Shop_Name can't be more than 100 characters")
    @Size(min=6, message="Shop_Name must be more than 5 characters")
    
    @Column(name="Shop_Address")
    private String Shop_Address;
    @NotBlank(message = "Shop_Address  can not be empty")
    @Size(max =100,message = "Shop_Address can't be more than 100 characters")
    @Size(min=6, message="Shop_Address must be more than 5 characters")
    
    @Column(name="Category")
    private String Category;
    @NotNull(message = "Category  can not be null")
    @Size(max =100,message = "Category can't be more than 100 characters")
    @Size(min=6, message="Category must be more than 5 characters")
    
    @Column(name="ShopTimings")
    private float Shop_Timings;
    @NotNull(message = "Shop_Timings  can not be null")
    
    @Column(name="Rating")
    private double Rating;
    @NotNull(message = "Rating can not be empty")
    
    public ShoppingMalls()
    {
    	
    }
	public ShoppingMalls(int shop_Id,
			@NotNull(message = "Shop Id can not be empty") @Size(max = 100, message = "Shop Id can't be more than 100 characters") @Size(min = 5, message = "Shop Id must be more than 5 characters") String shop_Name,
			@NotBlank(message = "Shop_Name  can not be empty") @Size(max = 100, message = "Shop_Name can't be more than 100 characters") @Size(min = 6, message = "Shop_Name must be more than 5 characters") String shop_Address,
			@NotBlank(message = "Shop_Address  can not be empty") @Size(max = 100, message = "Shop_Address can't be more than 100 characters") @Size(min = 6, message = "Shop_Address must be more than 5 characters") String category,
			@NotNull(message = "Category  can not be null") @Size(max = 100, message = "Category can't be more than 100 characters") @Size(min = 6, message = "Category must be more than 5 characters") float shop_Timings,
			@NotNull(message = "Shop_Timings  can not be null") double rating) {
		super();
		Shop_Id = shop_Id;
		Shop_Name = shop_Name;
		Shop_Address = shop_Address;
		Category = category;
		Shop_Timings = shop_Timings;
		Rating = rating;
	}
	public float getShop_Timings() {
		return Shop_Timings;
	}
	public void setShop_Timings(float shop_Timings) {
		Shop_Timings = shop_Timings;
	}
	public int getShop_Id() {
		return Shop_Id;
	}
	public void setShop_Id(int shop_Id) {
		Shop_Id = shop_Id;
	}
	public String getShop_Name() {
		return Shop_Name;
	}
	public void setShop_Name(String shop_Name) {
		Shop_Name = shop_Name;
	}
	public String getShop_Address() {
		return Shop_Address;
	}
	public void setShop_Address(String shop_Address) {
		Shop_Address = shop_Address;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public double getRating() {
		return Rating;
	}
	public void setRating(double rating) {
		Rating = rating;
	}
    
	

	
    
}
