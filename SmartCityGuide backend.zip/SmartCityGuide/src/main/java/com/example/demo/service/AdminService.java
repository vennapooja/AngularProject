package com.example.demo.service;

import com.example.demo.entity.Admin;

import java.util.List;
import java.util.Optional;

public interface AdminService {

    public List<Admin> findAll();
    public Optional<Admin> findById(int id);
    public void saveOrUpdate(Admin admin);
    public void deleteById(int id);
    Admin findAdminByNameofadmin(String nameofadmin);
    public List<Admin> findByAname(String nameofadmin);
	public Optional<Admin> getAdminByNameOfAdmin(String nameofadmin);
	

}
