package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.dao.TransportationFacilityDao;
import com.example.demo.entity.TransportationFacility;
@Service
public class TransportationFacilityServiceImpl implements TransportationFacilityService
{
	@Autowired
	TransportationFacilityDao dao;
	@Override
	public List<TransportationFacility> findAll() {
		return dao.findAll();
	}
	@Override
	public Optional<TransportationFacility> findById(int id) {
		return dao.findById(id);
	}
	@Override
    public void saveTransportation(TransportationFacility T) {
        dao.save(T);
	}   
	 @Override
		public void saveorUpdate(TransportationFacility T) {
			dao.save(T);
		}
	 @Override
		public void deleteById(int id) {
			dao.deleteById(id);
			
		}
	@Override
	public Optional<TransportationFacility> getTransportationFacilityBytransportationType(String transportationType) {
		// TODO Auto-generated method stub
		//return Optional.empty();
		return this.dao.findBytransportationTypeIgnoreCase(transportationType);
	}
	

			
}